package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.servlet.ModelAndView;

import com.demo.model.LoginInfo;

@Controller
public class LoginController {

	@GetMapping(value = "/")
	
	public ModelAndView display() {
		
		return new ModelAndView("login", "LoginInfo",new LoginInfo());
		
	}
	
	@PostMapping(value="/validation")
	
	public ModelAndView validation( @ModelAttribute("LoginInfo") LoginInfo loginInfo ) {
		
		if(loginInfo.getuName().equalsIgnoreCase("test")&&loginInfo.getUpass().equalsIgnoreCase("test")) {
			return new ModelAndView("home");
		}
		else {
			ModelAndView mv = new ModelAndView("login", "LoginInfo",new LoginInfo());
			mv.addObject("msg", "Invalid user name or password");
			return mv;
		}
		
	}
	
	
}
