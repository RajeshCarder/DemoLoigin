package com.demo.model;

import org.springframework.stereotype.Component;

@Component
public class LoginInfo {

	private String uName;
	private String upass;
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getUpass() {
		return upass;
	}
	public void setUpass(String upass) {
		this.upass = upass;
	}
	
}
